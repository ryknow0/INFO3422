//Hero class/property that is used by the heroes components to pass the data around
export class Hero {
    id: number;
    name: string;
}